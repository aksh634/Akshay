#include "main.h"

int pattern2()
{
	static unsigned int LED = 1;
	static int flag = 0;

	if (flag == 0)
	{
		PORTB = PORTB | ((1 << LED) - 1);                    // led on left to right one by one
		LED++;

		if (LED > 8)
		{
			flag = 1;
			LED = 1;
		}
	}
	else if (flag == 1)
	{
		PORTB = PORTB & ~((1 << LED) - 1);                  // led off left to right one by one
		LED++;

		if (LED > 8)
		{
			flag = 0;
			LED = 1;
		}
	}
}
