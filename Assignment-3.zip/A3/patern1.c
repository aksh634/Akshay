#include "main.h"

int pattern1()
{
	static unsigned int LED = 1;

/* when we press sw1 it will produce train led pattern */
	if (LED < 8)                                 
	{
		PORTB = (PORTB << 1 ) | 1 ;
		LED++;
	}
	else if (LED >= 8 && LED < 16 )
	{
		PORTB = PORTB << 1;
		LED++;
	}
	else if (LED >= 16 && LED < 24)
	{
		PORTB = ((PORTB  >> 1) | 0x80);
		LED++;
	}
	else if (LED >= 24 && LED < 32)
	{
		PORTB = (PORTB >> 1);
		LED++;
	}
	else
		LED = 0;
}

