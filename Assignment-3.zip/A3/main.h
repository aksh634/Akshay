#include <xc.h>

int pattern1();

int pattern2();

unsigned char read_key();

void init_config(void);
