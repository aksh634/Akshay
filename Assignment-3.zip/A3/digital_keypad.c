#include <xc.h>
#include "digital_keypad.h"

void init_digital_keypad(void)
{
	TRISC = TRISC | INPUT_PINS;                 // To make PORTC as input port
}

unsigned char read_digital_keypad(unsigned char detection_type)    // it is function defination
{
	static unsigned char once = 1;

	if (detection_type == STATE_CHANGE)                                    // this for edge triggering method for switch
	{
		if (((KEY_PORT & INPUT_PINS) != ALL_RELEASED) && once)
		{
			once = 0;

			return (KEY_PORT & INPUT_PINS);
		}
		else if ((KEY_PORT & INPUT_PINS) == ALL_RELEASED)
		{
			once = 1;
		}
	}
	else if (detection_type == LEVEL)                                       // this is for level triggering method for switch
	{
		return (KEY_PORT & INPUT_PINS);
	}

	return 0xFF;
}
