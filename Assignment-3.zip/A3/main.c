/*Documentation
Name : AKSHAY KUMAR B S
Date : 21-12-22
Description : A03 - Implement multiple patterns on LEDs controlled by switches
 */

#include <xc.h>
#include "main.h"
#include "digital_keypad.h"

void main()
{
	int flag = 0;                                            // variable declaration 
	unsigned char key;                                 
	unsigned long int delay = 0;

	init_config();                                           //  init_config function call

	init_digital_keypad();                                   //  init_digit_keypad function call

	while (1)
	{
		key = read_digital_keypad(STATE_CHANGE);               // function call

		if (key != ALL_RELEASED)                              // checking key not equal to ALL_RELEASED are not
		{
			if (key == SWITCH1)                               // checking key equal to sw1 are not
			{
				delay = 0;                                    // condition true means make delay equal to 0
				PORTB = 0x00;                                 // make led's off
				flag = 0;                                     // flag equal to 0
			}
			else if (key == SWITCH2)                         // checking key equal to sw2
			{
				delay = 0;                                   // condition true perform below expressions
				PORTB = 0x00;
				flag = 1;
			}
			else if (key == SWITCH3)                          // checking key equal to sw3 
			{
				delay = 0;
				PORTB = 0xAA;                                 // make portb as 0xAA 
				flag = 2;
			}
			else if (key == SWITCH4)                          // checking key equal to sw4 
			{
				delay = 0;
				PORTB = 0x0F;                                 // make portb as nibble
				flag = 3;
			}
		}

		if (delay++ == 100000)                               // delay for led 
		{
			if (flag == 0)                                   // checking flag equal to 0 are not
			{
				pattern1();                                  // function call
			}
			else if (flag == 1)                             // checking flag equal to 1 are not
			{
				pattern2();                                  // function call
			}
			else if (flag == 2 || flag == 3)                // checking flag equal to 2 are flag equal to 3 are not
			{
				PORTB = ~PORTB;                             // toggling PORTB
			}

			delay = 0;

		}
	}
}

void init_config(void)
{
	TRISB = 0x00;                   // To make PORTB as output port
	ADCON1 = 0x0F;                  // Make PORTB pins as Digital pins
	PORTB = 0x00;                   // By default all led's will be in off state

}
