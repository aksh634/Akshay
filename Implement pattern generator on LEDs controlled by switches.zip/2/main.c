/*Documentation
Name :AKSHAY KUMAR B S
Date : 22-12-22
Description : Implement pattern generator on LEDs controlled by switches
Documentation*/

#include <xc.h>
#include "main.h"
#include "digital_keypad.h"

/*function to perform the initial configuration of decelopment board pins*/
static void init_config(void)
{
	ADCON1 = 0x0F;
	LED_ARRAY = 0x00;
	TRISB = 0x00;
	PORTB = 0;
}

void main(void)
{
        init_config();

	unsigned long wait = 0;            //variable used for delay operation
	unsigned char count = 0, key, flag;       //declaring variables

	while(1)
	{
		key = read_digital_keypad(STATE_CHANGE);           //calling the digital keypad function and storing it in key
		if (key == SWITCH1)             //if switch1 is pressed set flag
		{
			flag = !flag;
		}

		if (wait++ == 50000)         //giving delay
		{
			if (flag == 0)           //if flag is 0 enter this loop
			{
				if (count < 8)      //logic to turn on leds from right to left
				{
					LED_ARRAY = LED_ARRAY << 1 | 1;
					count++;
				}
				else if(count < 16)          //logic to turn off leds from right to left
				{
					LED_ARRAY = LED_ARRAY << 1;
					count++;
				}
				else                 //to reduce the delay 
				{
					count = 1;
					LED_ARRAY = 0x01;
				}
			}
			else
			{
				if (count < 16 && count > 7)           //logic to turn on leds from left to right
				{
					LED_ARRAY = LED_ARRAY >> 1 | 0x80;
					count--;
				}
				else if (count < 8)             //logic to turn off leds from left to right
				{
					LED_ARRAY = LED_ARRAY >> 1;
					count--;
				}
				else             //to reduce the delay
				{
					count = 14;
					LED_ARRAY = 0x80;
				}
			}
			wait = 0;
		}
	}
}

