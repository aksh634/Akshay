#ifndef MAIN_H
#define MAIN_H

#define LED_ARRAY	PORTB

#endif
