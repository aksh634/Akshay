/*Documentation
Name : AKSHAY KUMAR B S
Date : 02-01-23
Description : A15 - Implement a left scrolling number marquee
*/

#include <xc.h>
#include "main.h"
#include "ssd_display.h"

static unsigned char ssd[MAX_SSD_CNT];              // we are declaring static variables globally
static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, BLANK, BLANK};

void init_config(void)
{
	init_ssd_control();                  // it is function call for init_ssd_control
}

void main(void)
{
	init_config();                          // it is function call for init_config

	unsigned long int wait = 0;                // we are declaring local variables  
	unsigned int a = 0, b = 1, c = 2, d = 3;

	while(1)
	{
		if (wait++ == 100)                          // it is non blocking delay
		{
			if (a == 12)                            // checking a equal to 12 are not
				a = 0;                              // true means make a to 0

			if (b == 12)                           // checking b equal to 12 are not
				b = 0;                             // true means make b to 0

			if (c == 12)                           // checking c equal to 12 are not
				c = 0;                             // true means make c to 0

			if (d == 12)                           // checking d equal to 12 are not
				d = 0;                             // true means make d to 0


			ssd[0] = digit[a++];                   // we are incrementing a
			ssd[1] = digit[b++];                   // we are incrementing b
			ssd[2] = digit[c++];                   // we are incrementing c
			ssd[3] = digit[d++];                   // we are incrementing d


			wait = 0;
		}

		display(ssd);
	}
}
