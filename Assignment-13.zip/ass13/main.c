/*Documentation
Name : AKSHAY KUMAR B S
Date : 21-12-22
Description :  A13 - Implement a 4 digit key press counter
*/ 

#include <xc.h>
#include "main.h"
#include "ssd_display.h"
#include "digital_keypad.h"

static unsigned char ssd[MAX_SSD_CNT];            // we are declaring static variables globally

static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};

void init_config(void)
{
	init_ssd_control();                                  //function call
}

void main(void)
{
	init_config();                                      //  function for init_config function
	init_digital_keypad();                              //  function call for digital keypad function

	unsigned short int key, count = 0, val = 0;        // we are declaring variables of short int datatype

	while(1)                                            // super loop 
	{
		key = read_digital_keypad(LEVEL);             // it is function call return value is storing in key variable

		if (key == SWITCH1)                           // checking key equal to switch1 are not
		{
			count++;                                  // count increment

			if (count == 200)                         // if checking count equal to 200 or not
			{
				val = 0;                              //  means make val equal to 0
			}
		}
		else if (count < 200 && count != 0)            // checking count lessthan 200 and count not equal to 0 are not
		{
			val++;                                    // true means increment value and make count to 0
			count = 0;
		}
		else                                          // condition false means make count to 0
			count = 0;

		ssd[3] = digit[val % 10];                     // displaying numbers on ssd
		ssd[2] = digit[val % 100/10];
		ssd[1] = digit[val % 1000/100];
		ssd[0] = digit[val % 10000/1000];

		display(ssd);
	}
}
