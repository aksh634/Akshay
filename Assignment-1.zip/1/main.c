/*Documentation
Name :AKSHAY KUMAR B S
Date : 16-12-22
Description : Implement LED train pattern on leds
Documentation*/


#include <xc.h>
#include "main.h"

/*function to perform the initial configuration of decelopment board pins*/
static void init_config(void)
{
	ADCON1 = 0x0F;
	LED_ARRAY = 0x00;
	TRISB = 0x00;
}

void main(void)
{
        init_config();                //calling the function
       	unsigned long wait = 0;            //variable used for delay operation
	unsigned char count = 0;             //variable used for counting

	while(1)               //run the infinitly
	{
		if (wait++ >= 65000)          //giving some delay to i
		{
			if (count < 8)           //to on led left to right one after other
			{
				LED_ARRAY |= (1 << count);
			}
			else if (count < 16)               //to off led left to right one anfter the other
			{
				LED_ARRAY <<= 1;
			}
			else if (count <24)                  //to on led right to left one after other
			{
				LED_ARRAY = (LED_ARRAY >> 1) | 0x80;
			}
			else if (count < 32)                     //to off led right to left one after other
			{
				LED_ARRAY >>= 1;
			}
			else
			{
				count = -1;                //to make 1st led on
			}
			count++;              //increment count;
		wait = 0;	                  //making delay as 0
		}
	}

}
