/*Documentation
Name : AKSHAY KUMAR BS 
Date : 02-01-23
Description : Implement a scrolling number marquee with direction control
*/

#include <xc.h>
#include "main.h"
#include "ssd_display.h"
#include "digital_keypad.h"

static unsigned char ssd[MAX_SSD_CNT];         // we are declaring static variable array globally
static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, BLANK, BLANK};

void init_config(void)
{
	init_ssd_control();                                 // it is function call for init_ssd_control function
}

void main(void)
{
	init_config();                                     // it is function call for init_config function
	init_digital_keypad();                             // it is function call for digital keypad function

	unsigned long int wait = 0;
	unsigned int a = 0, b = 1, c = 2, d = 3;           // we are declaring unsigned local variables
	unsigned char flag = 0, key;

	while(1)
	{
		if (wait++ == 100)                             // it is non blocking delay
		{
			key = read_digital_keypad(LEVEL);          // it is function call for level triggering return value stored in key variable

			if (key == SWITCH1)                       // checking key equal to switch1 are not
			{
				flag = 1;                             // true means make flag to 1
			}

			if (flag == 1)                            // checking flag equal to 1 are not
			{

				if (a == 0)                           // checking a equal to 0 are not
					a = 11;                           // true means make a to 11

				if (b == 0)                           // checking b equal to 0 are not
					b = 11;                           // true means make b to 11

				if (c == 0)                           // checking c equal to 0 are not
					c = 11;                           // true means make c to 11

				if (d == 0)                           // checking d equal to 0 are not
					d = 11;                           // true means make d to 11


				ssd[0] = digit[a--];                 
				ssd[1] = digit[b--];                 // logic for right scrolling when switch pressed
				ssd[2] = digit[c--];
				ssd[3] = digit[d--];
			}

			if (flag == 0)                               // checking flag equal to 0 are not
			{
				if (a == 12)                             // logic for left scrolling
					a = 0;

				if (b == 12)
					b = 0;

				if (c == 12)
					c = 0;

				if (d == 12)
					d = 0;


				ssd[0] = digit[a++];
				ssd[1] = digit[b++];
				ssd[2] = digit[c++];
				ssd[3] = digit[d++];
			}

			wait = 0;
		}

		display(ssd);
	}
}
